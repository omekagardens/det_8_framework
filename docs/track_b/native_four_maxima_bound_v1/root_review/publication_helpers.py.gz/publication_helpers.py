"""Root exact archive builder; source decisions and actual evidence remain distinct."""
import importlib.util
from pathlib import Path
import hashlib
_hp=Path('/Volumes/AI_DATA/development/det-review-evidence/ri122-root-execution-review-6whn_vky/metadata.py')
_hr=_hp.read_bytes()
assert len(_hr)==3144 and hashlib.sha256(_hr).hexdigest()=='d2825bb1ea78306388a410d9b5aa9b931f72cb6a78334bc69151560f6b2584a7'
sp=importlib.util.spec_from_file_location('metadata','/Volumes/AI_DATA/development/det-review-evidence/ri122-root-execution-review-6whn_vky/metadata.py')
m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);m.D=Path(__file__).resolve().parent
entry=m.load(m.D/'REPO_ENTRY.json');assert m.git('rev-parse','HEAD').decode().strip()==entry['head'] and m.git('diff','--cached','--name-only')==b''
by_pin={};tracked=set(m.git('ls-files','-z').decode().rstrip('\0').split('\0'));git_cache={}
for row in entry['files']:by_pin.setdefault((row['bytes'],row['sha256']),[]).append(row)
helper=m.ref(m.B/'ri122-root-execution-review-6whn_vky/metadata.py')
def packet(base,folder,key='files',omit=()):
 h=m.load(base/'HANDOFF.json');rows=h[key]
 assert sorted(p.name for p in base.iterdir())==sorted(['HANDOFF.json']+[Path(x['path']).name for x in rows])
 for row in rows:m.verify(row['path'],row)
 return [(Path(x['path']),folder+'/'+Path(x['path']).name) for x in rows if Path(x['path']).name not in omit]+[(base/'HANDOFF.json',folder+'/HANDOFF.json')]
def archive(bundle,origins,rows,readme,source_only):
 dest=m.REPO/bundle;dest.mkdir(exist_ok=False);copies=[]
 assert len({rel for _,rel in origins})==len(origins)
 for original,rel in origins:
  r=m.ref(original);p=dest/rel;p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb') as f:f.write(original.read_bytes())
  m.verify(p,r);assert p.read_bytes()==original.read_bytes();copies.append(dict(path=rel,original=r))
 deps=[]
 for r in rows:
  m.verify(r['path'],r);record=dict(original=r);same=[x for x in copies if m.pure(x['original'])==m.pure(r)]
  if same:record.update(location='archive',path=same[0]['path'])
  else:
   found=None
   for old in by_pin.get((r['bytes'],r['sha256']),[]):
    rel=str(Path(old['path']).relative_to(m.REPO))
    if rel in tracked:
     if rel not in git_cache:git_cache[rel]=m.pin(m.git('show',entry['head']+':'+rel))
     if git_cache[rel]==m.pure(r):found=rel;break
   if found:record.update(location='existing_git',path=found,commit=entry['head'])
   else:record.update(location='external_original',path=r['path'])
  deps.append(record)
 counts={}
 for row in deps:counts[row['location']]=counts.get(row['location'],0)+1
 (dest/'DEPENDENCY_MAP.json').write_bytes(m.canonical(dict(schema='review-checkpoint-publication-map-v1',parent=entry['head'],copies=copies,dependencies=deps,dependency_locations=counts,all_transitive_dependencies_archived=False,complete_runtime_archive=False,source_only=source_only,relocated_execution_authorized=False)))
 (dest/'README.md').write_text(readme)
 payload=[dict(path=str(p.relative_to(dest)),**m.pure(m.ref(p))) for p in sorted(dest.rglob('*')) if p.is_file()]
 (dest/'PUBLICATION_MANIFEST.json').write_bytes(m.canonical(dict(schema='review-checkpoint-publication-manifest-v1',parent=entry['head'],payload=payload,exact_copies=len(copies),source_only=source_only,relocated_execution_authorized=False)))
 return dict(bundle=bundle,payload=len(payload),copies=len(copies),dependencies=len(deps),dependency_locations=counts,source_only=source_only)

