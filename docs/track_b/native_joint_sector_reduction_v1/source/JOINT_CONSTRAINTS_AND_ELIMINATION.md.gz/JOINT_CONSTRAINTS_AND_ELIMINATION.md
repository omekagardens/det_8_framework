> Public redacted derivative. The prose below records historical research and review; local paths, private file fingerprints and execution identifiers have been obscured. Raw custody, host/runtime logs and administrative scripts are withheld. Claims about exact copies, complete transcripts, byte identities, manifests or execution permissions describe the private original archive, not this derivative. Only the new PUBLICATION_MANIFEST.json hashes verify the redacted payloads. This copy grants no execution authority and cannot replay original custody checks.

# Complete joint sector constraints and unique elimination

1 October 2026, OBSCURED-LOCATION. RI266 manual author result pending independent
adjudication. The proposed eleven-to-four conditional reduction is valid
with the complete marked residual caps and original selector retained.

The eleven free coordinates are kappa_i, tau_i, both nu_(i,j), both
eta_(i,l), four xi_(i,l,m) and sigma_i. Every other ACTUAL allocation
remains fixed at the SAME full feasible canonical rest. In particular
mu, the other sector and all accepted canonical zero roles remain fixed.
This is not an arbitrary feasible original vector with different zero
roles, a freely supplied capacity model, or a new canonical law.

The seven eliminated coordinates are unique at each feasible retained
tuple (tau_i,nu_(i,0),nu_(i,1),sigma_i). The second note proves exact
projection, compactness, attained concave piecewise-affine value and
recovery through the ORIGINAL full-vector lex selector. No actual
coefficient, residual, support or optimizer is acquired.

## Original component inventory and residual independence

Fix i and abbreviate only admitted positive lower coefficients

    p=p_i, v=v_i, h_l=h_(i,l), n_l=n_(i,l), s_lm=s_(i,l,m),
    a0=41/352, bar_s=(s_00+s_01+s_10+s_11)/4.             (J1)

Use kappa,tau,nu_j,eta_l,xi_lm,sigma for this fixed sector. They are
eleven distinct original coordinates, not newly introduced free laws.
RI231 CANONICAL_CAPACITY exhausts P; RI248 COMPANION_ROW exhausts the
companion and every terminal's other presentation. RI264 retains the
first four-coordinate inventory. Together they give

| Coordinate | Complete carrying parents | Potentials |
| --- | --- | --- |
| kappa_i | P, Y | a0, 1/64 |
| tau_i | P, P_tau | v, p |
| nu_(i,j) | P, P_nu | n_l, p |
| eta_(i,l) | P_tau, Q | h_l, v |
| xi_(i,l,m) | P_tau, P_nu | n_l, v |
| sigma_i | P_tau, V5 | s_lm, v/40 per compatible singleton |

Each component terminal has exactly two maxima; deleting either
exhausts every parent presentation, since ratio paths preserve the
terminal. Distinct terminal types separate these families. Eta and
nu have the same height/relation count but different descendant counts
at their second minimum, so they do not merge. Compulsory r,o marks
distinguish the two eta coordinates; compulsory r,o,x marks distinguish
the four xi. Nu retains r,a; kappa,tau,sigma retain r. All optional
marks are related only by the admitted full incidence, with both
newborn bits and every whole record preserved.

Thus Q carries only the compatible eta_l among the eleven. A given
Q marking contains exactly that eta occurrence, not the other eta
or a newly free kappa,tau,nu,xi,sigma contribution. Define B_Q as
the sum of EVERY other original proper contribution in that row.
The inventory proves it is fixed independently of ALL eleven.

Likewise P_nu carries exactly its compatible nu_j and xi_lm among
the eleven. Define B_nu after excluding BOTH displayed contributions.
It contains every other original proper contribution and is independent
of all eleven by the same inventory. No residual independence is
inferred merely from the symbol B. P_mu and every unlisted parent
have no changed coordinate and stay fixed.

For V5, both singleton ideals must be counted separately. Its two
minimum marks may coincide, but this changes row multiplicity of a
coordinate, not the number of original sigma coordinates.

## Complete marked rows before any elimination

Use i,j,k,l,m on P for r,a,b,o,x; on Q and P_nu use i,j,l,m,k
with k the top z bit. On P_tau, t is the y bit. Every applicable
marking obeys the full original canonical inequalities

    a0*kappa+v*tau+n_l*nu_j+t_K(i,j,k,l,m)*mu_(i,l)<=1,  (J2)

    kappa/64<=1,                                      (J3)

    B_Q(i,j,l,m,k)+v*eta_l<=1,                         (J4)

    p*tau+h_l*eta_l+n_l*xi_lm+s_lm*sigma<=1,            (J5)

    B_nu(i,j,l,m,k)+p*nu_j+v*xi_lm<=1.                 (J6)

The other six P proper roles and other five P_tau proper roles are
zero by the accepted canonical neutrality argument, not silently
deleted. Q and P_nu remainders may be nonzero or binding.

At fixed i, P and P_tau each have sixteen records. There are four
P(k,m) markings for each l,j, eight Q(j,m,k) markings for each l,
and four P_nu(j,k) markings for each l,m. J5 repeats for all four
j,t at each l,m by admitted coefficient transport, not because
those records have been removed. All carrying Y rows remain.

Write a V5 whole marking as omega=(b,d,other marks), with b,d the
two minimum bits, NOT the earlier fixed root sector i. Its complete
row before collecting the one varying sigma is

    B_V(omega)+(v_b/40)*sigma_b+(v_d/40)*sigma_d<=1.    (J7)

B_V sums every other original proper contribution. Define

    gamma_i(omega)=(v/40)*[1_(b=i)+1_(d=i)],

    D_i(omega)=B_V(omega)
       +(v_b/40)*sigma_b*1_(b!=i)
       +(v_d/40)*sigma_d*1_(d!=i).                     (J8)

Then every V5 row is D_i(omega)+gamma_i(omega)*sigma<=1.
D_i is fixed: all other-sector sigma and unlisted contributions
are included. If b=d=i the coefficient is v/20, not v/40.
If exactly one minimum has bit i the coefficient is v/40 and
the other sector's sigma stays in D_i. If neither has bit i,
the row has no varying coordinate and remains an explicit
fixed-rest feasibility prerequisite.

This retains all mixed-sector rows, both identical-sector occurrences,
all remaining record marks and equivariant labelings. No symmetry
average substitutes for one of these inequalities.

## Exact caps from this same rest

Define only the following UNEVALUATED minima of original residuals:

    R_lj=min_(k,m)[1-t_K(i,j,k,l,m)*mu_(i,l)],

    E_l=min_(j,m,k)[1-B_Q(i,j,l,m,k)]/v,

    S=min_(omega:gamma_i(omega)>0)
                         [1-D_i(omega)]/gamma_i(omega). (J9)

All sets are finite and nonempty. Both V5 singleton presentations
are included in S, including every mixed-sector row and every row
with coefficient v/20. Feasibility of the same original point and
nonnegativity of its contributions give

    0<=R_lj<=1, 0<=E_l<=1/v, 0<=S<infinity.            (J10)

Finite S follows because each included gamma is positive and finite
and at least one such V5 row exists. Nothing divides by a zero
coefficient: gamma=0 rows remain among the fixed prerequisites.
All unchanged original rows, including those V5 rows, must already
be feasible. Those prerequisites are inherited from the fixed point,
not verified by evaluating data in this packet.

Retain w=(tau,nu_0,nu_1,sigma)>=0 and define

    c_lm(w)=1-p*tau-s_lm*sigma,

    U_lm(w)=min_(j,k)
                   [1-B_nu(i,j,l,m,k)-p*nu_j]/v,

    rho(w)=min_(l,j)[R_lj-v*tau-n_l*nu_j].              (J11)

U includes BOTH j and all k for each l,m. In particular xi must
satisfy both distinct nu groups simultaneously. None of R,E,S,B_Q,
B_nu or D_i is an independently selectable capacity. J11 explicitly
retains the shared retained-coordinate dependence that RI264's
fixed-compensator N_j and T caps could not encode.

Subject to the fixed-rest prerequisites, the exact retained domain is

    D={w>=0:
           sigma<=S,
           c_lm(w)>=0 for every l,m,
           U_lm(w)>=0 for every l,m,
           R_lj-v*tau-n_l*nu_j>=0 for every l,j}.       (J12)

All implications, including the converse, will be checked below.
Zero capacities are legal. Negative upper endpoints mean a tuple
is outside D, not an available interval with its sign discarded.

## Y redundancy and the exact fiber

Do not drop J3 in advance. For any feasible block, nonnegativity
and all J2 inequalities imply

    0<=a0*kappa<=rho(w)<=1,
    kappa<=352/41<64.                                 (J13)

The final inequality follows from the retained R_lj<=1 and
tau,nu>=0. Thus J3 is derived redundant, even after eta,xi,sigma
are freed: none occurs in P or Y.

For a_l=h_l*eta_l, the complete feasible fiber at w in D is

    0<=kappa<=rho(w)/a0,

    0<=a_l<=A_l(w)=min{h_l*E_l,c_l0(w),c_l1(w)},

    0<=xi_lm<=min{U_lm(w),(c_lm(w)-a_l)/n_l}.           (J14)

Positivity of h_l,n_l makes the change of variables invertible and
every denominator valid. J12 and E_l>=0 give A_l>=0. Every upper
xi bound in J14 is nonnegative.

Necessity of J12–J14 follows from J2–J8 and all original
nonnegativity constraints. Conversely, at any w in D, setting
kappa=eta=xi=0 already satisfies every affected row and J3.
More generally EVERY vector in J14 satisfies J2–J8 for every
carrying record, by the exact minima. No other row changes.
Therefore D is exactly the full linear feasible set's projection,
and J14 is its entire fiber, not merely a sufficient candidate.

This argument also proves there is no hidden Q, P_nu or V5
restriction left in the eliminated variables. A singleton fiber
or a zero A_l,U_lm,rho is included without a limiting argument.
Freeing a coordinate that was zero at the original point is allowed;
old ray-specific decreasing-support restrictions are not reused.

## Whole-history reward for all eleven coordinates

The admitted per-record weights, retaining newborn factors, are

    Pi_P=3p/1280, Pi_tau=7v/3840,
    Pi_Q=h_l/480, Pi_nu=n_l/768.                        (J15)

RI254 COMPENSATION_COVER derives the latter two from the eight
Q and five P_nu linear extensions and w_N=1/384; RI264 retains
the P and P_tau prices. At fixed sector, their relevant sums are

    Pi_P,i=3p/80, Pi_tau,i=7v/240,
    Pi_tau,i,l=7v/480, Pi_tau,i,l,m=7v/960,
    Pi_Q,i,l=h_l/60, Pi_nu,i,l,m=n_l/192.               (J16)

Every repeated j,t or j,k record contributes. Hence the eta,
xi and sigma rewards per unit original allocation are

    h_l*(7v/480)+v*(h_l/60)=v*h_l/32,

    n_l*(7v/960)+v*(n_l/192)=v*n_l/80,

    sum_(l,m) s_lm*(7v/960)=7v*bar_s/240.              (J17)

Y and V5 have zero full defect increment, so contribute no primary
reward, but all their constraints remain. No cross-sector V5
reward is invented. The original primary objective is a fixed
constant minus the full positive reward

    W=(3p*a0/80)*kappa+(p*v/15)*tau
       +c_nu*(nu_0+nu_1)
       +(v/32)*sum_l a_l
       +(v/80)*sum_(l,m) n_l*xi_lm
       +c_sigma*sigma,

    c_nu=7p*(n_0+n_1)/480>0,
    c_sigma=7v*bar_s/240>0.                            (J18)

The tau coefficient includes BOTH P and P_tau; each nu coefficient
includes BOTH P and P_nu exactly as derived in RI264. This is
the unchanged whole-history objective on the restricted block.

## Strict finite difference dominance and unique recovery

At fixed w, kappa is independent of the eta/xi fiber in J14.
Its strictly positive reward gives the unique choice

    kappa(w)=rho(w)/a0.                                (J19)

For a fixed feasible a_l, every xi_lm reward is strictly positive,
so both xi values uniquely equal their upper bounds. The remaining
block-l reward, apart from retained terms, is

    f_l(a)=v*a/32
       +(v/80)*sum_(m=0,1) min{n_l*U_lm,c_lm-a},
       0<=a<=A_l.                                    (J20)

Take ANY two feasible a<a' and set delta=a'-a>0. For a fixed K,
the change in min(K,c-a) when a increases by delta lies in
[-delta,0]: monotonicity gives the upper bound, and lowering
one argument by delta cannot lower their minimum by more than
delta. Therefore, including every switch and tie,

    f_l(a')-f_l(a)
       >=v*delta/32-2*v*delta/80
       =v*delta/160>0.                                (J21)

This is a finite-difference proof, not an assumed derivative.
It holds across any number of coincident active bounds. It includes
zero U or c where two feasible a values exist; if A_l=0 the only
feasible a is already unique. No unavailable or negative interval
is admitted.

Thus the proposed seven-coordinate elimination is uniquely correct:

    a_l(w)=A_l(w), eta_l(w)=A_l(w)/h_l,

    xi_lm(w)=min{U_lm(w),(c_lm(w)-A_l(w))/n_l},

    kappa(w)=rho(w)/a0.                                (J22)

At a fixed retained w, any different seven-coordinate fiber vector
has strictly lower reward: a nonmaximal kappa loses independently;
a nonmaximal xi loses at fixed a; and after optimizing xi, any
nonmaximal a loses by J21. All endpoint cases remain. Uniqueness
is established BEFORE projecting the original lex problem.

This completes the exact domain and fiber reduction. The next note
proves the remaining value and full-vector lex image, retaining all
conditional/global distinctions and original source boundaries.

