> Public redacted derivative. The prose below records historical research and review; local paths, private file fingerprints and execution identifiers have been obscured. Raw custody, host/runtime logs and administrative scripts are withheld. Claims about exact copies, complete transcripts, byte identities, manifests or execution permissions describe the private original archive, not this derivative. Only the new PUBLICATION_MANIFEST.json hashes verify the redacted payloads. This copy grants no execution authority and cannot replay original custody checks.

# Joint sector block handoff

1 October 2026, OBSCURED-LOCATION. RI266 source-only manual author result pending
independent root adjudication. The proposed exact conditional
eleven-to-four reduction is proved, without evaluating the actual
canonical rest or any residual.

The eleven free original coordinates are kappa, tau, two nu, two eta,
four xi and sigma in one fixed root sector. Every other ACTUAL
allocation stays fixed to the SAME full feasible canonical rest.
The complete P/Y/Q/P_tau/P_nu/V5 inventory is retained. It proves
Q's residual excludes all eleven, while P_nu's residual excludes
its displayed nu and xi and every other newly free coordinate.
No residual is treated as an independent supplied capacity.

V5 retains every mixed-sector record and BOTH singleton occurrences.
The sigma coefficient is v/40 when one minimum has the sector bit,
and v/20 when both do. The exact sigma cap includes all these rows;
rows with no varying sigma remain fixed-rest prerequisites.

At retained w=(tau,nu_0,nu_1,sigma), define all-record residuals
R_lj,E_l,S and the coupled functions

    c_lm=1-p*tau-s_lm*sigma,
    U_lm=min_(j,k)[1-B_nu(i,j,l,m,k)-p*nu_j]/v,
    rho=min_(l,j)[R_lj-v*tau-n_l*nu_j],
    A_l=min{h_l*E_l,c_l0,c_l1}.

The exact projected domain has w>=0, sigma<=S, every c_lm>=0,
every U_lm>=0 and every P residual>=0, together with the original
fixed-rest prerequisites. Y<=64 is kept until P proves its redundancy.

Whole-history prices give the UNIQUE eliminated entries

    kappa=rho/a0, eta_l=A_l/h_l,
    xi_lm=min{U_lm,(c_lm-A_l)/n_l}.

The decisive finite-difference proof gives an eta-over-two-xi reward
gain of at least v*delta/160 for ANY feasible positive delta. It
retains ties, zero caps and singleton intervals without differentiability.

The complete eleven-variable linear feasible set is compact, and
its projection is exactly the stated four-variable polytope. The
remaining value is concave by partial maximization over that SAME
linear feasible set, continuous and piecewise affine. An exact finite
branch description retains all ties and flat faces; no small vertex
count or numeric branch evaluation is claimed.

The full primary-optimal set is exactly the reconstructed image of
the reduced maximizers. Uniqueness makes recovery affine on that
optimal face. The lex choice stays the ORIGINAL full-vector sequential
choice on that image. No guessed ordering of all eleven, four-variable
lex order or recycled RI264 smallest-r rule is substituted.

Canonical kappa equals rho(w*)/a0: it is zero iff some P residual
vanishes at the selected tuple, and positive iff all four are positive.
Actual residuals, maximizing face, original lex restrictions and a
sharper evaluated sign criterion remain unresolved. This is necessary
conditional optimality only, not global sufficiency, a kappa-gap/C_b
decision, a full normalized witness or a signed inconsistency.

RI262's circulation family remains closed. Stop at this bounded proof
for root/nonauthor review; no successor or acquisition is assigned.

All original equations/recovery/offsets/selector, u2=-1, d=0!=d7 and
normalized existence iff actual C_b=0 remain. All15 typed/raw boundaries,
the exact43,739-byte raw value and423 unexpanded manifest references
remain. All scientific/RI250 routes stay closed. No body/hash/checker,
scientific JSON, engine, new actual coefficient/cap/support acquisition,
scientific execution, vector/H/z reconstruction, measurement/RET or
repository/Git/index/publication operation occurred. Administrative
checks verify custody only; independent mathematical acceptance
remains pending. Root retains every operational/publication decision.

