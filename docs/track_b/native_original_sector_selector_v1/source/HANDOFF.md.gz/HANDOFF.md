> Public redacted derivative. The prose below records historical research and review; local paths, private file fingerprints and execution identifiers have been obscured. Raw custody, host/runtime logs and administrative scripts are withheld. Claims about exact copies, complete transcripts, byte identities, manifests or execution permissions describe the private original archive, not this derivative. Only the new PUBLICATION_MANIFEST.json hashes verify the redacted payloads. This copy grants no execution authority and cannot replay original custody checks.

# Original sector order handoff

1 October 2026, OBSCURED-LOCATION. RI268 manual author result pending independent
root/nonauthor adjudication. Kappa is proved earliest among all eleven
varying original coordinates in RI266's same-rest sector block.

The missing Q lower bound is complete. Its strict relations are
(r,a),(r,z),(a,z),(o,z),(r,x),(o,x). There are exactly eight
topological orders: five r-first and three o-first. The manual table
covers all eight, including both orders with a source3-to-top4 bit.
It proves minimum E_5(Q)=8988, rather than treating one attaining
example as a lower bound.

The accepted topological-minimum lemma extends this result to all
carrier permutations. Combining ALL presentations gives P>=8730,
P_tau>=8604, Q>=8988, and P_nu,V5>=2^19. Every tau,nu,eta,xi,sigma
component therefore has first key coordinate greater than kappa's
original (8590,17,i), for every compulsory mark and selected mask.
The exhaustive two-parent component inventory rules out an omitted
earlier presentation. No rank, coefficient or vector is acquired.

Fixed interleaved original coordinates cannot reverse the first
difference when kappa differs. Thus on RI266's compact primary-optimal
image E(M), the original lex selector first imposes

    kappa*=rho_min/a0,  rho_min=min_(w in M)rho(w).

It then continues in the unchanged original order on the entire
minimum-rho face. No order among the remaining ten is invented.

This resolves the mixed case rho_min=0<rho_max: canonical kappa is
ZERO, although positive-kappa primary optima remain. A positive
rho_min gives positive canonical kappa exactly rho_min/a0. Constant,
singleton, zero-capacity and flat-face cases are retained; compactness
rules out a missing zero infimum.

The result is conditional. No actual rho_min, cap, optimizer, kappa
sign/value/gap or C_b is evaluated. Same-point global/other-sector/
dual compatibility remains required; no full normalized witness or
signed inconsistency follows.

All original equations/recovery/offsets/selector, u2=-1, d=0!=d7 and
normalized existence iff actual C_b=0 remain. All15 whole typed/raw
boundaries, exact43,739-byte raw value and423 unexpanded references
remain. Original scientific/RI250 routes stay closed. Manual finite
ordering proof only; no automated enumeration, engine, new coefficient/
cap/support acquisition, vector/H/z reconstruction, scientific execution,
measurement/RET or repository/Git/index/publication operation.

Stop at the sealed bounded proof for independent review. RI262's
circulation family remains closed. No successor or operation is
assigned; root retains those decisions. Administrative custody
checks are separate from mathematical and independent acceptance.

